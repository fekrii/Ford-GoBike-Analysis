# (Ford-GoBike-Analysis)
## by (Abdulrahman Fekri)


## Dataset

> I choosed the Ford-GoBike 2019 feb Data set .
> This data set includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area.


## Summary of Findings

> Univariate Exploration: first i fixed the data types of the values to be able to perform on it , then i calculated some variables from others . like the age of the user from his date of birth and the month, day and hour of the trip from start_date column.
then i was able to plot the propagation of the duration in hours , duration in minutes , the start day and the start hour. also the propagation of user types (subscribers and users) and the user age.

> Bivariate Exploration: in this section i was able to investigate the relation between two pairs like the age and the duration in seconds which i find there is a negative relationship between them .
also i plotted the relation between week days and user types which i find that subscribers uses the trips in different days than customers 

> Multivariate Exploration : in this last section i was able to plot the relation between three variables which are user types , duration and day of the week . and that confirmed my previous insight which is customers and subscribers have different times in using the trips for example : customers use there trips in saturdays and sundays way too more than subscribers.


## Key Insights for Presentation

> In the analysis of this data sets i was able to find the relationship between user types (subscribers or cutomers) and the duration they spent in bike trips and the days they most use it .
> and i was able to find that subscribers use the trips at avarage level all days of the week except for saturdays and sundays which is more used by customers and that is due to the different in style between these two .